
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'lukeshay',
  applicationName: 'luke-jadi-wedding-email',
  appUid: 'nfqrmhPYr5lS4hK5pk',
  orgUid: '44ZxQb7bCgtBfLHXFM',
  deploymentUid: 'b81b1a75-692c-49e9-a5a7-25f98a663148',
  serviceName: 'email',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'development',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '4.5.3',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'email-development-emailer', timeout: 6 };

try {
  const userHandler = require('./emailer.js');
  module.exports.handler = serverlessSDK.handler(userHandler.email, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}